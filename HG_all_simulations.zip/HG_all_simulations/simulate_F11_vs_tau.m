%% Clear environment and add required paths
clear;clc;
warning('off','all')
format longE; %Increase float precision
addpath('./HG_MIT');
addpath('./HG_Chan');

%hg_mode = 'Laplace_approx';
%hg_mode = 'truncated_sum_MIT';
%hg_mode = 'truncated_sum_Chan';

Modes = ["truncated_sum_MIT", "Laplace_approx"];%, "truncated_sum_Chan"];
Legends = ["Exact confluent HG function", "Laplace approximation"];%, "truncated_sum_Chan"];
Styles = ["bs--", "r*", "gx-", "ko-", "bs-", "yd-"];

d = 5;
a = 3;
b = 4;
tau = [0.01, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8];
I_d = eye(d);
sz_tau = length(tau);
sz_Modes = length(Modes);
log_HG_11 = zeros(1,sz_tau);
Eig = zeros(sz_tau,d);
for m = 1:sz_Modes
    hg_mode = Modes(m);
    for i = 1:sz_tau
        Eig(i,:) = eig(tau(i)*I_d);
        switch hg_mode
            case 'Laplace_approx'
                log_HG_11(i) = approx_F11(a, b, Eig(i,:));
            case 'truncated_sum_MIT'
                log_HG_11(i) = F11_MIT(a, b, Eig(i,:));
                sprintf('tau=%.2f(%d/%d)',tau(i),i,sz_tau)
            case 'truncated_sum_Chan'
                log_HG_11(i) = F11_Chan(a, b, Eig(i,:));
        end
    end
    title_str = sprintf('d=%d, a=%d, b=%d', d, a, b);
    title(title_str,'interpreter','latex','FontSize',12);
    hold on; grid on;
    set(gca, 'YScale', 'log');
    semilogy(tau, exp(log_HG_11), Styles(m), 'LineWidth', 1);
    xlabel('\tau', 'FontSize', 12);
    ylabel('Function Value', 'FontSize', 12);
    sprintf('%s:',Legends(m))
    sprintf('(%.2f,%f)',[tau;exp(log_HG_11)])
end
legend(Legends,'Location','northwest');