function W = moment_F21(p1, p2, n, s, P)
log_W = gamma_multi_ln(p1,n/2)+gamma_multi_ln(p1,((n-p2)/2)+s)-gamma_multi_ln(p1,(n/2)+s)-gamma_multi_ln(p1,(n-p2)/2)+(n/2)*log(det(eye(p1)-P.^(2)))+approx_F21(n/2,n/2,(n/2)+s,eig(P.^(2)));
W = exp(log_W);
end