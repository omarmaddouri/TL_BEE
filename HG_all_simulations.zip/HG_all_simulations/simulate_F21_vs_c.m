%% Clear environment and add required paths
clear;clc;
warning('off','all')
format longE; %Increase float precision
addpath('./HG_MIT');
addpath('./HG_Chan');

%hg_mode = 'Laplace_approx';
%hg_mode = 'truncated_sum_MIT';
%hg_mode = 'truncated_sum_Chan';

Modes = ["truncated_sum_MIT", "Laplace_approx"];%, "truncated_sum_Chan"];
Legends = ["Exact Gauss HG function", "Laplace approximation"];%, "truncated_sum_Chan"];
Styles = ["bs--", "r*", "gx-", "ko-", "bs-", "yd-"];

d = 10;
a = 30;
b = 50;
c = [10, 14, 16, 18, 22, 24, 26, 28, 32, 34, 36, 40, 44, 46, 48, 50];
tau = 0.01;
I_d = eye(d);
sz_c = length(c);
sz_Modes = length(Modes);
log_HG_21 = zeros(1,sz_c);
Eig = zeros(sz_c,d);
for m = 1:sz_Modes
    hg_mode = Modes(m);
    for i = 1:sz_c
        Eig(i,:) = eig(tau*I_d);
        switch hg_mode
            case 'Laplace_approx'
                log_HG_21(i) = approx_F21(a, b, c(i), Eig(i,:));
            case 'truncated_sum_MIT'
                log_HG_21(i) = F21_MIT(a, b, c(i), Eig(i,:));
                sprintf('c=%d(%d/%d)',c(i),i,sz_c)
            case 'truncated_sum_Chan'
                log_HG_21(i) = F21_Chan(a, b, c(i), Eig(i,:));
        end
    end
    title_str = sprintf('d=%d, a=%d, b=%d, $\\tau$=%.2f', d, a, b, tau);
    title(title_str,'interpreter','latex','FontSize',12);
    hold on; grid on;
    set(gca, 'YScale', 'log');
    semilogy(c, exp(log_HG_21), Styles(m), 'LineWidth', 1);
    xlabel('c', 'FontSize', 12);
    ylabel('Function Value', 'FontSize', 12);
    sprintf('%s:',Legends(m))
    sprintf('(%d,%f)',[c;exp(log_HG_21)])
end
legend(Legends);