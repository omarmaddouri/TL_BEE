function log_F01_hat = approx_F01(a,eigs)
%Returns 0F1(a/2;(1/4)XX')
x = eigs;
m = length(x);

u = 2*x/a;
y = u./(sqrt(u.^2 + 1)+1);

R = 0;
for i = 1:m
    for j = i:m
        R = R + log((1-y(i)^2*y(j)^2));
    end
end
K = sum((a/2)*log(1-y.^2)+ x.*y);
log_F01_hat = -.5*R + K;



