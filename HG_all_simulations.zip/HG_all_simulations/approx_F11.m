function log_F11_hat = approx_F11(a,b,eigs)

x = eigs;
p = length(x);

y = 2*a./(b - x + sqrt((x - b).^2 + 4 * a .* x));

R = 0;
for i = 1:p
    for j = i:p
        R = R + log(y(i)*y(j)/a + (1-y(i))*(1-y(j))/(b-a));
    end
end

K = sum(a*log(y/a) + (b-a)*log((1-y)/(b-a)) + x.*y);

log_F11_hat = (b*p - p*(p+1)/4)*log(b) - .5*R + K;



