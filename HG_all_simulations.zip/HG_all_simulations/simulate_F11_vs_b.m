%% Clear environment and add required paths
clear;clc;
warning('off','all')
format longE; %Increase float precision
addpath('./HG_MIT');
addpath('./HG_Chan');

%hg_mode = 'Laplace_approx';
%hg_mode = 'truncated_sum_MIT';
%hg_mode = 'truncated_sum_Chan';

Modes = ["truncated_sum_MIT", "Laplace_approx"];%, "truncated_sum_Chan"];
Legends = ["Exact confluent HG function", "Laplace approximation"];%, "truncated_sum_Chan"];
Styles = ["bs--", "r*", "gx-", "ko-", "bs-", "yd-"];

d = 10;
a = 30;
b = [10, 14, 16, 18, 22, 24, 26, 28, 32, 34, 36, 40, 44, 46, 48, 50];
tau = 0.01;
I_d = eye(d);
sz_b = length(b);
sz_Modes = length(Modes);
log_HG_11 = zeros(1,sz_b);
Eig = zeros(sz_b,d);
for m = 1:sz_Modes
    hg_mode = Modes(m);
    for i = 1:sz_b
        Eig(i,:) = eig(tau*I_d);
        switch hg_mode
            case 'Laplace_approx'
                log_HG_11(i) = approx_F11(a, b(i), Eig(i,:));
            case 'truncated_sum_MIT'
                log_HG_11(i) = F11_MIT(a, b(i), Eig(i,:));
                sprintf('b=%d(%d/%d)',b(i),i,sz_b)
            case 'truncated_sum_Chan'
                log_HG_11(i) = F11_Chan(a, b(i), Eig(i,:));
        end
    end
    title_str = sprintf('d=%d, a=%d, $\\tau$=%.2f', d, a, tau);
    title(title_str,'interpreter','latex','FontSize',12);
    hold on; grid on;
    set(gca, 'YScale', 'log');
    semilogy(b, exp(log_HG_11), Styles(m), 'LineWidth', 1);
    xlabel('b', 'FontSize', 12);
    ylabel('Function Value', 'FontSize', 12);
    sprintf('%s:',Legends(m))
    sprintf('(%d,%f)',[b;exp(log_HG_11)])
end
legend(Legends);