%% Clear environment and add required paths
clear;clc;
warning('off','all')
format longE; %Increase float precision
addpath('./HG_MIT');
addpath('./HG_Chan');


p1 = 2;
p2 = 3;
n = 10;
P = eye(2);
P(1,1) = 0.3;
P(2,2) = 0.8;
s = 1;
W = moment_F21(p1, p2, n, s, P)