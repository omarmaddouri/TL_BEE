module load Matlab/R2020a
alias matlabsubmit_customized='$SCRATCH/matlabsubmit_customized/matlabsubmit'
cd d_3/n_t_10/n_t_10_alpha_099
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_095
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_09
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_085
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_08
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_075
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_07
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_065
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_06
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_055
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_05
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_045
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_04
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_035
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_03
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_025
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_02
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_015
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_01
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_005
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_t_10_alpha_001
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
