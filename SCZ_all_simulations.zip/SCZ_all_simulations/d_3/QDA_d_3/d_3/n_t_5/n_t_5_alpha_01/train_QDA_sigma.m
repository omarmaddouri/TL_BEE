function QDA = train_QDA_sigma(mu, Sigma, L)
Lambda = cell(1,L);
for ll = 1:L
    mu{ll} = reshape(mu{ll},[],1);
    Lambda{ll} = Sigma{ll}^(-1);
end

c = 1/2;%prior class 0
A = (-1/2) * (Lambda{2} - Lambda{1});
a = (Lambda{2} * mu{2} - Lambda{1} * mu{1});
b = -(1/2) * ( (mu{2}' * Lambda{2} * mu{2}) - (mu{1}' * Lambda{1} * mu{1}) )...
    - (1/2) * log(det(Lambda{1})/det(Lambda{2}))...
    - log((1-c)/c);

QDA.A = A;
QDA.a = a;
QDA.b = b;
end