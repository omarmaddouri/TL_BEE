function LDA = train_LDA(mu, Sigma, L)
for ll = 1:L
    mu{ll} = reshape(mu{ll},[],1);
end
pooled_Sigma = (Sigma{1}+Sigma{2})/2;
a = pooled_Sigma^(-1)*(mu{2} - mu{1});
b = (-1/2) * a' * (mu{2} + mu{1});
LDA.a = a;
LDA.b = b;
end