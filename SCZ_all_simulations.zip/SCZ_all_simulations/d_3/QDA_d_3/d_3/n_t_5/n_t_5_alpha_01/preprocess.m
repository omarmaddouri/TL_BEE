%% Clear environment and add required paths
clear;clc;
warning('off','all')
warning
format longE; %Increase float precision

%% Load target data
datExpr_t = readtable('datExpr_t.csv','PreserveVariableNames',true);
datMeta_t = readtable('datMeta_t.csv','PreserveVariableNames',true);
datProbes_t = readtable('datProbes_t.csv','PreserveVariableNames',true);

%% Load source data
datExpr_s = readtable('datExpr_s.csv','PreserveVariableNames',true);
datMeta_s = readtable('datMeta_s.csv','PreserveVariableNames',true);
datProbes_s = readtable('datProbes_s.csv','PreserveVariableNames',true);

%% Define feature set and phenotype
%feature_set = ["FERMT2",  "METTL7A", "PON2", "EMX2", "TP53BP2"];
%feature_set = ["GRAMD3",  "GJA1", "HEPH", "NOTCH2", "PPAP2B"];
%feature_set = ["RAB31",  "LRP4", "SOX9", "ACSBG1", "CLDN10"];
%feature_set = ["SOX9", "AHCYL1", "CLDN10", "LRIG1", "ADORA2B"];
feature_set = ["SOX9", "AHCYL1", "CLDN10"];
Diagnosis_t = ["SCZ", "Control"];
Diagnosis_s = ["SCZ", "Control"];

%% Parse target data
idx_Probes_features_t = [];
for i=1:length(feature_set)
    idx_Probes_features_t = [idx_Probes_features_t, find(table2array(datProbes_t(:,"external_gene_id"))==feature_set(i))];
end
ensembl_t = string(table2array(datProbes_t(idx_Probes_features_t,"Var1")));

idx_Meta_samples_scz_t = find(table2array(datMeta_t(:,"Dx"))==Diagnosis_t(1));
idx_Meta_samples_ctrl_t = find(table2array(datMeta_t(:,"Dx"))==Diagnosis_t(2));
n_t_scz = length(idx_Meta_samples_scz_t);
n_t_ctrl = length(idx_Meta_samples_ctrl_t);
idx_Meta_samples_t = [idx_Meta_samples_scz_t; idx_Meta_samples_ctrl_t];
samples_t = table2array(datMeta_t(idx_Meta_samples_t,"Var1"));

idx_Expr_features_t=[];
for i=1:length(ensembl_t)
    idx_Expr_features_t = [idx_Expr_features_t, find(table2array(datExpr_t(:,"Var1")) == ensembl_t(i))];
end
D_t = table2array(datExpr_t(idx_Expr_features_t,samples_t))';
D_t= [zscore(D_t(1:n_t_scz, :)); zscore(D_t(n_t_scz+1:end, :))];
Label_t = [ones(n_t_scz,1); 2*ones(n_t_ctrl,1)];
%%%%%%%%%%%%%%%%%%%%
%% Parse source data
idx_Probes_features_s = [];
for i=1:length(feature_set)
    idx_Probes_features_s = [idx_Probes_features_s, find(table2array(datProbes_s(:,"external_gene_id"))==feature_set(i))];
end
ensembl_s = string(table2array(datProbes_s(idx_Probes_features_s,"Var1")));

idx_Meta_samples_scz_s = find(table2array(datMeta_s(:,"Diagnosis"))==Diagnosis_s(1));
idx_Meta_samples_ctrl_s = find(table2array(datMeta_s(:,"Diagnosis"))==Diagnosis_s(2));
n_s_scz = length(idx_Meta_samples_scz_s);
n_s_ctrl = length(idx_Meta_samples_ctrl_s);
idx_Meta_samples_s = [idx_Meta_samples_scz_s; idx_Meta_samples_ctrl_s];
samples_s = table2array(datMeta_s(idx_Meta_samples_s,"Var1"));

idx_Expr_features_s=[];
for i=1:length(ensembl_s)
    idx_Expr_features_s = [idx_Expr_features_s, find(table2array(datExpr_s(:,"Var1")) == ensembl_s(i))];
end
D_s = table2array(datExpr_s(idx_Expr_features_s,samples_s))';
D_s= [zscore(D_s(1:n_s_scz, :)); zscore(D_s(n_s_scz+1:end, :))];
Label_s = [ones(n_s_scz,1); 2*ones(n_s_ctrl,1)];
%%%%%%%%%%%%%%%%%%%%
%% Perform Shapiro-Wilk tests
% cnfd_lvl = 0.05;
% for i=1:size(D_t,2)
%     d_t = D_t(1:n_t_scz, i);
%     %d_t = D_t(n_t_scz+1:end, i);
%     [H, pValue, W] = swtest(d_t, cnfd_lvl);
%     if H==1
%         i
%         disp("Shapiro-Wilk test rejected normality");
%     end
% end
%% Perform Royston's normality tests
% Roystest(D_t(1:n_t_scz, :), 0.01)
% Roystest(D_t(n_t_scz+1:end, :), 0.01)
% Roystest(D_s(1:n_s_scz, :), 0.01)
% Roystest(D_s(n_s_scz+1:end, :), 0.01)
