function param = setup_parameters_scz(d, L, D_t, D_s, nu, alpha, n_t, n_s)

param.d = d;
param.L = L;

for i = 1:L    
    % nu:
    param.nu{i} = nu;
    
    % kappa:
    param.kappa_t{i} = n_t;
    param.kappa_s{i} = n_s;
    
    % m:
    param.m_t{i} = mean([D_t{1};D_t{2}], 1);
    param.m_s{i} = mean([D_s{1};D_s{2}], 1);
    
    % M:
    k_t = 1/nu;
    k_s = 1/nu;
    param.k_t = k_t;
    param.k_s = k_s;
    param.alpha = alpha;
    param.M_t{i} = k_t * diag(ones(1,d));
    param.M_s{i} = k_s * diag(ones(1,d));
    param.M_ts{i} = param.alpha * sqrt(k_t * k_s) * eye(d);
    param.M{i} = [param.M_t{i} param.M_ts{i}; param.M_ts{i}' param.M_s{i}];
    param.M_t_inv{i} = param.M_t{i}^-1;
    
    % C & F:
    param.C{i} = param.M_s{i} - param.M_ts{i}' * param.M_t_inv{i} * param.M_ts{i};
    param.C_inv{i} = param.C{i}^-1;
    param.F{i} = param.C{i}^-1 * param.M_ts{i}' * param.M_t_inv{i};
    param.F_inv{i} = param.F{i}^-1;

end
end




