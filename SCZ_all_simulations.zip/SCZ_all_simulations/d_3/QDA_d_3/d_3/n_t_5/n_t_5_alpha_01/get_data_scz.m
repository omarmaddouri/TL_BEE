function [X, S, Label] = get_data_scz(D_t, Labels_t, n_t_scz, n_t_ctrl,...
                                           D_s, Labels_s, n_s, n_t, nc, seed)

X.test = cell(1, nc);
X.t = cell(1, nc);
X.s = cell(1, nc);
X.t_mean = cell(1, nc);
X.s_mean = cell(1, nc);
S.t = cell(1, nc);
S.s = cell(1, nc);
X.test_all = [];
Label.test_all = [];

n_t=10;
idx_t_train = cell(1, nc);
idx_t_test = cell(1, nc);
p_t_scz = n_t_scz-n_t;
rng(seed);
partition_t_scz = cvpartition(n_t_scz,'Holdout',p_t_scz);
idx_t_train{1} = training(partition_t_scz);
idx_t_test{1} = test(partition_t_scz);

p_t_ctrl = n_t_ctrl-n_t;
rng(seed);
partition_t_ctrl = cvpartition(n_t_ctrl,'Holdout',p_t_ctrl);
idx_t_train{2} = training(partition_t_ctrl);
idx_t_test{2} = test(partition_t_ctrl);

for i = 1:nc
    if i==1
    end
    % Test (for target)
    X.test{i} = D_t{i}(idx_t_test{i},:);
    X.test_all = [X.test_all; X.test{i}];
    Label.test{i} = Labels_t{i}(idx_t_test{i},:)';
    Label.test_all = [Label.test_all Label.test{i}];
    
    
    % Train (for both target and source)
    X.t{i} = D_t{i}(idx_t_train{i},:);
    Label.t{i} = Labels_t{i}(idx_t_train{i},:)';
    
    X.s{i} = D_s{i};
    rng(seed);
    X.s{i} = X.s{i}(randperm(size(X.s{i}, 1)), :);
    Label.s{i} = Labels_s{i}';
    
    
    % Sample mean and covariance
    X.t_mean{i} = mean(X.t{i});
    
    X.s_mean{i} = mean(X.s{i});
    
    S.t{i} = (X.t{i} - repmat(X.t_mean{i},n_t,1))' * (X.t{i} - repmat(X.t_mean{i},n_t,1));
    S.s{i} = (X.s{i} - repmat(X.s_mean{i},n_s,1))' * (X.s{i} - repmat(X.s_mean{i},n_s,1));
end

