%% Clear environment and add required paths
clear;clc;
warning('off','all')
format longE; %Increase float precision
addpath('./HG_MIT');
addpath('./HG_Chan');
addpath('/scratch/user/omar.maddouri/STAN/MatlabStan-2.15.1.0')
addpath('/scratch/user/omar.maddouri/STAN/MatlabProcessManager')
addpath('D:/Installations/STAN/MatlabStan-2.15.1.0')
addpath('D:/Installations/STAN/MatlabProcessManager')

%% Define STAN model code
% Stan code for joint posterior of target and source parameters
JPo_ts_code = {
'data {'
'    int<lower=0> n_t;'
'    int<lower=0> n_s;'
'    int<lower=2> d;'
'    vector[d] m_t;'
'    vector[d] m_s;'
'    int<lower=0> kappa_t;'
'    int<lower=0> kappa_s;'
'    matrix[2*d,2*d] M;'
'    int<lower=d> nu;'
'    matrix[n_t+n_s,d] x;'
'}'
'transformed data{'
'    matrix[2*d,2*d] L_M;'
'    L_M = cholesky_decompose(M);'
'}'
'parameters {'
'    vector[d] mu_t;'
'    vector[d] mu_s;'
'    vector<lower=0>[2*d] c_Lambda;'
'    vector[d*(2*d-1)] n_Lambda;'
'}'
'transformed parameters{'
'    matrix[2*d,2*d] A_Lambda;'
'    matrix[2*d,2*d] Lambda;'
'    matrix[d,d] Lambda_t;'
'    matrix[d,d] Lambda_s;'
'    for (i in 1:2*d){'
'        for (j in 1:2*d){'
'            if(i==j)'
'               A_Lambda[i,j] = sqrt(c_Lambda[i]);'
'            else if(i>j)'
'               A_Lambda[i,j] = n_Lambda[(j+(i-1)*(i-2)/2)];'
'            else'
'               A_Lambda[i,j] = 0.0;'
'        }'
'    }'
'    Lambda = L_M * A_Lambda * A_Lambda'' * L_M'';'
'    Lambda_t = Lambda[1:d,1:d];'
'    Lambda_s = Lambda[(d+1):(2*d),(d+1):(2*d)];'
'}'
'model {'
'     for (i in 1:2*d){'
'         c_Lambda[i] ~ chi_square(nu-i+1);'
'     }'
'    for (i in 1:d*(2*d-1)){'
'         n_Lambda[i] ~ normal(0, 1);'
'     }'
'   mu_t ~ multi_normal(m_t, inverse(kappa_t*Lambda_t));'
'   mu_s ~ multi_normal(m_s, inverse(kappa_s*Lambda_s));'
'   for (i in 1:n_t){'
'       x[i,:] ~ multi_normal(mu_t, inverse(Lambda_t));'
'   }'
'   for (i in n_t+1:n_t+n_s){'
'       x[i,:] ~ multi_normal(mu_s, inverse(Lambda_s));'
'   }'
'}'
 };

%% Define constants
d = 3;  % number of features
L = 2;   % number of classes
N_t = [5]; % array of numbers of target data per class
N_s = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 53]; % array of numbers of source data per class
nu = 30; % Degrees of freedom

N_test = 10^(3); % Size of test target data per class
Sz_sample = 10^(3); % Size of MC sample (rule of thumb -> 10 times more than the quantity being estimated)
N_p = 10^(0); % number of repeats of the simulations for different parameters
N_d = 10^(4); % number of repeats of MC sampling for different datasets to estimate the MSE

Alpha = [0.3];% Relatedness coefficients

style = ["b*-", "rs-", "gx-", "ko-", "bs-", "yd-", "gd-", "mh-", "k*-", "c^-"];
legends = ["$\alpha=0.95$", "$\alpha=0.9$", "$\alpha=0.8$", "$\alpha=0.7$", "$\alpha=0.6$", "$\alpha=0.5$", "$\alpha=0.4$", "$\alpha=0.3$", "$\alpha=0.2$", "$\alpha=0.1$"];

Sz_target = length(N_t); % size of array containing train target data numbers
Sz_source = length(N_s); % size of array containing train source data numbers
Sz_alpha = length(Alpha); % size of array containing train source data numbers

%% Load target data
datExpr_t = readtable('datExpr_t.csv','PreserveVariableNames',true);
datMeta_t = readtable('datMeta_t.csv','PreserveVariableNames',true);
datProbes_t = readtable('datProbes_t.csv','PreserveVariableNames',true);

%% Load source data
datExpr_s = readtable('datExpr_s.csv','PreserveVariableNames',true);
datMeta_s = readtable('datMeta_s.csv','PreserveVariableNames',true);
datProbes_s = readtable('datProbes_s.csv','PreserveVariableNames',true);

%% Define feature set and phenotype
feature_set = ["SOX9", "AHCYL1", "CLDN10"];
Diagnosis_t = ["SCZ", "Control"];
Diagnosis_s = ["SCZ", "Control"];

%% Parse target data
idx_Probes_features_t = [];
for i=1:length(feature_set)
    idx_Probes_features_t = [idx_Probes_features_t, find(table2array(datProbes_t(:,"external_gene_id"))==feature_set(i))];
end
ensembl_t = string(table2array(datProbes_t(idx_Probes_features_t,"Var1")));

idx_Meta_samples_scz_t = find(table2array(datMeta_t(:,"Dx"))==Diagnosis_t(1));
idx_Meta_samples_ctrl_t = find(table2array(datMeta_t(:,"Dx"))==Diagnosis_t(2));
n_t_scz = length(idx_Meta_samples_scz_t);
n_t_ctrl = length(idx_Meta_samples_ctrl_t);
idx_Meta_samples_t = [idx_Meta_samples_scz_t; idx_Meta_samples_ctrl_t];
samples_t = table2array(datMeta_t(idx_Meta_samples_t,"Var1"));

idx_Expr_features_t=[];
for i=1:length(ensembl_t)
    idx_Expr_features_t = [idx_Expr_features_t, find(table2array(datExpr_t(:,"Var1")) == ensembl_t(i))];
end
D_t = table2array(datExpr_t(idx_Expr_features_t,samples_t))';
D_t_cell = cell(1, L);
Label_t_cell = cell(1, L);
D_t_cell{1} = zscore(D_t(1:n_t_scz, :));
D_t_cell{2} = zscore(D_t(n_t_scz+1:end, :));
Label_t_cell{1} = ones(n_t_scz,1);
Label_t_cell{2} = 2*ones(n_t_ctrl,1);
%%%%%%%%%%%%%%%%%%%%
%% Parse source data
idx_Probes_features_s = [];
for i=1:length(feature_set)
    idx_Probes_features_s = [idx_Probes_features_s, find(table2array(datProbes_s(:,"external_gene_id"))==feature_set(i))];
end
ensembl_s = string(table2array(datProbes_s(idx_Probes_features_s,"Var1")));

idx_Meta_samples_scz_s = find(table2array(datMeta_s(:,"Diagnosis"))==Diagnosis_s(1));
idx_Meta_samples_ctrl_s = find(table2array(datMeta_s(:,"Diagnosis"))==Diagnosis_s(2));
n_s_scz = length(idx_Meta_samples_scz_s);
n_s_ctrl = length(idx_Meta_samples_ctrl_s);
idx_Meta_samples_s = [idx_Meta_samples_scz_s; idx_Meta_samples_ctrl_s];
samples_s = table2array(datMeta_s(idx_Meta_samples_s,"Var1"));

idx_Expr_features_s=[];
for i=1:length(ensembl_s)
    idx_Expr_features_s = [idx_Expr_features_s, find(table2array(datExpr_s(:,"Var1")) == ensembl_s(i))];
end
D_s = table2array(datExpr_s(idx_Expr_features_s,samples_s))';
D_s_cell = cell(1, L);
Label_s_cell = cell(1, L);
D_s_cell{1} = zscore(D_s(1:n_s_scz, :));
D_s_cell{2} = zscore(D_s(n_s_scz+1:end, :));
Label_s_cell{1} = ones(n_s_scz,1);
Label_s_cell{2} = 2*ones(n_s_ctrl,1);
%%%%%%%%%%%%%%%%%%%%
sampling_mode = 'stan_posterior_hmc';
nchains = 4;% Set the number of sampling chains
seed = 123; %random seed
seeds = zeros(1, N_d);

%% Define Global variables
Avg_MSE_QDA = zeros(Sz_alpha, Sz_target, Sz_source); % Average MSE after N_p trials
Avg_Bayes_error = zeros(1, Sz_alpha); % Average Bayes error across all relatedness coefficients
Bayes_error = zeros(1, N_p);
MSE_QDA = zeros(N_p, Sz_target, Sz_source);

tmp_D_t = cell(1, L);
tmp_D_s = cell(1, L);
for i = 1:L
    tmp_D_t{i} = randn(N_t(1),d);
    tmp_D_s{i} = randn(N_s(1),d);
end
param = setup_parameters_scz(d, L, tmp_D_t, tmp_D_s, nu, Alpha(1), N_t(1), N_s(1));
if (~exist('posterior_QDA.stan', 'file'))
    TL_joint_data = struct('n_t', N_t(1), 'n_s', N_s(1), 'd', d, 'm_t', param.m_t{1}, 'm_s', param.m_s{1}, 'kappa_t', param.kappa_t{1}, 'kappa_s', param.kappa_s{1}, 'M', param.M{1}, 'nu', param.nu{1}, 'x', [tmp_D_t{1};tmp_D_s{1}]);
    fit_TL_joint_initial = stan('model_code', JPo_ts_code, 'data', TL_joint_data,'model_name', 'posterior_QDA', 'chains', 1, 'iter', 100, 'file_overwrite', true);
    fit_TL_joint_initial.block();
else
    fit_TL_joint_initial = stan('file', 'posterior_QDA.stan');
end

%% Simulations
rng(seed);
for n_d = 1:N_d
	seeds(n_d) = randi([100,999]);
end
% LOOP over relatedness coefficients
for alpha_idx = 1:Sz_alpha
    alpha = Alpha(alpha_idx);
    fprintf('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n');
    fprintf('---> alpha = %.2f ### (%.2d/%.2d)\n', alpha, alpha_idx, Sz_alpha);
    % LOOP for different parameters realisations
    for n_p = 1:N_p
        SE_QDA = zeros(N_d, Sz_target, Sz_source);
        param_scz = cell(N_d, Sz_source);
        %% Loop for different datasets realisations
        for n_d = 1:N_d
            BEE_QDA = zeros(1, Sz_source);
            
            % if ~exist([tempdir 'worker_' num2str(n_d)], 'dir')
                % mkdir([tempdir 'worker_' num2str(n_d)]);
            % end
            % TL_joint_data(n_d) = struct('n_t', N_t(1), 'n_s', N_s(1), 'd', d, 'm_t', param.m_t{1}, 'm_s', param.m_s{1}, 'kappa_t', param.kappa_t{1}, 'kappa_s', param.kappa_s{1}, 'M', param.M{1}, 'nu', param.nu{1}, 'x', randn(N_t(1)+N_s(1),d));
            % fit_TL_joint(n_d) = stan('fit', fit_TL_joint_initial, 'data', TL_joint_data(n_d), 'chains', 1, 'iter', 100, 'working_dir',[tempdir 'worker_' num2str(n_d)]);
            % fit_TL_joint(n_d).block();
                    
            fprintf('---------------> N_d = (%.2d/%.2d) ---> (alpha = %.2f)\n', n_d, N_d, alpha);
            [X_full, S_full, Label_full] = get_data_scz(D_t_cell, Label_t_cell, n_t_scz, n_t_ctrl, D_s_cell, Label_s_cell, n_s_scz, N_t(end), L, seeds(n_d));
            %% Determine QDA classifier (Bayes classifier)
            QDA_Bayes = train_QDA_sigma(X_full.t_mean, S_full.t, L);
            Bayes_error(n_p) = test_set_error_QDA(QDA_Bayes, X_full, Label_full);
            for n_t_idx = 1:Sz_target
                n_t = N_t(n_t_idx);
%                 fprintf('---------------------> N_t = %.2d ### (%.2d/%.2d) ---> (alpha = %.2f)\n', n_t, n_t_idx, Sz_target, alpha);
                parfor n_s_idx = 1:Sz_source
                    n_s = N_s(n_s_idx);                                        
                    
                    if ~exist([tempdir 'worker_' num2str(n_s_idx)], 'dir')
                        mkdir([tempdir 'worker_' num2str(n_s_idx)]);
                    end
                    TL_joint_data(n_s_idx) = struct('n_t', n_t, 'n_s', n_s, 'd', d, 'm_t', param.m_t{1}, 'm_s', param.m_s{1}, 'kappa_t', param.kappa_t{1}, 'kappa_s', param.kappa_s{1}, 'M', param.M{1}, 'nu', param.nu{1}, 'x', randn(n_t+n_s,d));
                    fit_TL_joint(n_s_idx) = stan('fit', fit_TL_joint_initial, 'data', TL_joint_data(n_s_idx), 'chains', 1, 'iter', 100, 'working_dir',[tempdir 'worker_' num2str(n_s_idx)], 'seed', seeds(n_d));
                    fit_TL_joint(n_s_idx).block();
            
                    Mixed_BEE = zeros(1, Sz_sample);                    
                    %fprintf('---------------------------> N_s = %.2d ### (%.2d/%.2d) ---> (alpha = %.2f)\n', n_s, n_s_idx, Sz_source, alpha);
%                     [X_train, S_train, ~] = generate_data(mu_t, mu_s, Lambda_t, Lambda_s, L, n_t, n_s, N_test, seeds(n_d));
                    [X_train, S_train] = get_partial_data(X_full, L, n_t, n_s);
                    param_scz{n_d, n_s_idx} = setup_parameters_scz(d, L, X_train.t, X_train.s, nu, alpha, n_t, n_s);
                    switch sampling_mode
                        case 'stan_posterior_hmc'
                            [theta_mu_t, theta_Lambda_t] = sample_joint_hmc_stan(fit_TL_joint(n_s_idx), Sz_sample, param_scz{n_d, n_s_idx}, X_train, n_t, n_s, nchains, seeds(n_d));
                            for t = 1:Sz_sample
                                try
                                    Mixed_BEE(t) = test_error_QDA(QDA_Bayes, param_scz{n_d, n_s_idx}, {theta_mu_t{t,:}}, {theta_Lambda_t{t,:}}, N_test, seeds(n_d));
                                catch ME
                                    Mixed_BEE(t) = -1;
                                end
                            end
                            Mixed_BEE(Mixed_BEE==-1) = mean(Mixed_BEE(Mixed_BEE~=-1));
                            BEE_QDA(n_s_idx) = (1/Sz_sample) * sum( Mixed_BEE);
                    end
                end
                % Compute the squared error of the BEE
                SE_QDA(n_d, n_t_idx, :) = (BEE_QDA - Bayes_error(n_p)).^2;
            end
        end
        % Estimate MSE for a given n_t
        MSE_QDA(n_p,:,:) = mean(SE_QDA,1);
    end
    Avg_MSE_QDA(alpha_idx,:,:) = mean(MSE_QDA, 1);
    Avg_Bayes_error(alpha_idx) = mean(Bayes_error);
    
    %% Save results
    for n_t_idx =1:Sz_target
        save_name = sprintf('QDA_MSE_n_t_%1d_alpha_%g.mat', N_t(n_t_idx), Alpha(:));
        save(save_name, 'Sz_target', 'Sz_source', 'Sz_alpha', 'style', 'legends',...
            'Avg_MSE_QDA', 'N_t', 'N_s', 'Alpha', 'Avg_Bayes_error');
    end
end