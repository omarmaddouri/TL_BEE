%% Clear environment and add required paths
clear;clc;
warning('off','all')
warning
format longE; %Increase float precision

legend_list = [0.95, 0.9, 0.7, 0.5, 0.3, 0.1];
%legend_list = [0.95];
for f = 1:length(legend_list)
    try
        load(['QDA_MSE_n_t_50_alpha_' num2str(legend_list(f),'%.2f') '.mat']);
    catch ME
        load(['QDA_MSE_n_t_50_alpha_' num2str(legend_list(f),'%.1f') '.mat']);
    end
    style = ["b*-", "rs-", "gx-", "ko-", "bs-", "yd-"];
    legends = ["$\alpha=0.95$", "$\alpha=0.9$", "$\alpha=0.7$", "$\alpha=0.5$", "$\alpha=0.3$", "$\alpha=0.1$"];

    %% Plot MSE vs N_s
    for j =1:Sz_target
        title_str = sprintf('$n_{t}$ = %2d, $n_{s}$ = %.2d', N_t(j), N_s(end));
        title(title_str,'interpreter','latex','FontSize',12);
        hold on;
        for i =1:Sz_alpha
            alpha = Alpha(i);
            MSE = squeeze(Avg_MSE_QDA_vs_Bayes(i,j,:));
            plot(Bayes_errors_range, MSE, style(find(legend_list==alpha)), 'LineWidth', 1);
            sprintf('(%d,%f)',[Bayes_errors_range;MSE'])
        end

        legend(legends(1:find(legend_list==alpha)), 'interpreter', 'latex', 'FontSize', 9, 'Location', 'northeast', 'NumColumns', 2);
        xlabel('$\varepsilon_{Bayes}$', 'FontSize', 12, 'interpreter', 'latex');
        ylabel('MSE', 'FontSize', 12);
        hold off;
    end
end