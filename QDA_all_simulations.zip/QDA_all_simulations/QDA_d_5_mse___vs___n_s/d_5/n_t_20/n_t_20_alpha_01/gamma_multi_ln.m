function out = gamma_multi_ln(d,alpha)
if d~=1
    out = (d*(d-1)/4) * log(pi);

    for i = 1:d
        out = out + gammaln(alpha - ((i-1)/2));
    end
else
    out = gammaln(alpha);
end
end