function log_F21_hat = approx_F21(a,b,c,eigs)
x = eigs;
d = length(x);

tau = x * (b - a) - c;
y = 2*a./(sqrt(tau.^2 - 4 * a .* x * (c - b)) - tau);

R = 0;
for i = 1:d
    for j = i:d
        R = R + log(y(i)*y(j)/a + (1-y(i))*(1-y(j))/(c-a) ...
            - b*x(i)*x(j)*y(i)*y(j)*(1-y(i))*(1-y(j))/((1-x(i)*y(i))*(1-x(j)*y(j))*a*(c-a)));
    end
end

K = sum(a*log(y/a) + (c-a)*log((1-y)/(c-a)) - b*log(1-x.*y));

log_F21_hat = (c*d - d*(d+1)/4)*log(c) - .5*R + K;
end