function [CW, coef_ctrl_var] = control_variate_weights(param, theta_mu_t, theta_Lambda_t, H, EH, IW, f)
% %This function computes the weights of the importance sampling
L = param.L;
Sz_sample = max(size(theta_mu_t));
CW = zeros(Sz_sample, L);
coef_ctrl_var = zeros(1,L);
var_ctrl_var = zeros(1,L);
cov_ctrl_var = zeros(1,L);
for i = 1:Sz_sample
    for j = 1:L
        theta_mu_t{i,j} = reshape(theta_mu_t{i,j},[],1);
        CW(i,j) = H(theta_mu_t{i,j}, theta_Lambda_t{i,j},j);
    end
end

for j = 1:L
	cov_ctrl_var(j) = (1/Sz_sample) * sum( (IW(:,j) .* f(:,j) - mean(IW(:,j) .* f(:,j))) .* (CW(:,j) - EH{j}));
    var_ctrl_var(j) = (1/Sz_sample) * sum( (CW(:,j)-EH{j}).^(2));
    coef_ctrl_var(j) = cov_ctrl_var(j)/var_ctrl_var(j);
end

end