function error = class_test_error_QDA(QDA, param, mu_t, Lambda_t, N_test, seed)
L = param.L;
[X_error, ~, Label_error] = generate_data(mu_t, 0, Lambda_t, 0, L, 0, 0, 2*N_test, seed);
error = zeros(1,L);
for l = 1:L
    n_test = length(Label_error.test{l});
    predicted_label = zeros(1, n_test);
    for i = 1:n_test
        x = reshape(X_error.test{l}(i,:),[],1);
        predicted_label(i) = x' * QDA.A * x + x' * QDA.a + QDA.b;
    end
    predicted_label(predicted_label>0) = 2;
    predicted_label(predicted_label<=0) = 1;
    accuracy = sum(predicted_label == Label_error.test{l})/n_test;
    error(l) = (1 - accuracy);
end

end