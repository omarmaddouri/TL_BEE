function EH = expected_control_variate(param, classifier, M_t, nu, m_t, kappa_t)
%This function returns a the expected value of the LDA error with respect
%to the importance density

L = param.L;
d = param.d;
A = cell(1,L);
EH = cell(1,L);
for i = 1:L
    kappa_t{i} = 1;
    A{i} = (-1)^(i-1) * (classifier.a' * m_t{i} + classifier.b) * sqrt(1/(kappa_t{i}+1));
    EH{i} = (1/2) + (sign(A{i})/2) * betainc((A{i}^2)/(A{i}^2 + classifier.a' * M_t{i}^(-1) * classifier.a), 1/2, (nu{i}-d+1)/2);
end
end

