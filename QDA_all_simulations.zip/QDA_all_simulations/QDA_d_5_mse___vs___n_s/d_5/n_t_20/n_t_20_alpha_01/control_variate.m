function H = control_variate(classifier)
%This function returns a function handle for the control variate
%Control variate: Error of LDA classifier
H = @(mu,Lambda,i) (normcdf((-1)^(i-1)*(classifier.a' * mu + classifier.b)/sqrt(classifier.a' * Lambda^(-1) * classifier.a)));
end

