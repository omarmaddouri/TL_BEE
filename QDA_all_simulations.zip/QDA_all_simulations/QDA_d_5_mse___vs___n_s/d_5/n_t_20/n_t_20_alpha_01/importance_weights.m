function IW = importance_weights(param, theta_mu_t, theta_Lambda_t, P, Q)
% %This function computes the importance likelihood ratios
L = param.L;
Sz_sample = max(size(theta_mu_t));
IW = zeros(Sz_sample, L);
for i = 1:Sz_sample
    for j = 1:L
        theta_mu_t{i,j} = reshape(theta_mu_t{i,j},[],1);
        IW(i,j) = P{j}(theta_mu_t{i,j}, theta_Lambda_t{i,j}) / Q{j}(theta_mu_t{i,j}, theta_Lambda_t{i,j});
    end
end
end
