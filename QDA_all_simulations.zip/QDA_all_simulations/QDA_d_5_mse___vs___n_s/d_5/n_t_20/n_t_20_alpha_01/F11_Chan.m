function log_F11_hat = F11_Chan(a,b,eigs)
%Truncated sum of F11 (returns the log estimate)
computeHG('clearData')
computeHG('setMaxMem', 500 * 1024 * 1024);
N = 10; % number of series in HG function
N_max = 100; % Maximum number of series in HG function
[F11_hat, byPartitionSize] = computeHG(2, N, a, b, eigs);
NN = N;
while F11_hat/sum(byPartitionSize(1:NN)) > 1.001
    NN = NN + 10;
    [F11_hat, byPartitionSize] = computeHG(2, NN, a, b, eigs);
    if NN > N_max
        disp(['N > ' num2str(N_max)])
        break
    end
end
log_F11_hat = log(F11_hat);
end