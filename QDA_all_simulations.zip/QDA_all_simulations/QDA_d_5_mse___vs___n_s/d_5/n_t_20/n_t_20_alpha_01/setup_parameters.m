function param = setup_parameters(d, L, mean_shift, nu, alpha)

param.d = d;
param.L = L;

for i = 1:L
    
    %Distance between the mean of the target classes for a Bayes error of 0.2
    dist_class_means = mean_shift;
    
    % nu:
    param.nu{i} = nu;
    
    % kappa:
    param.kappa_t{i} = 100;
    param.kappa_s{i} = 100;
    
    % m:
    param.m_t{i} = dist_class_means * (i-1) * ones(1,d);
    param.m_s{i} = param.m_t{i} + 10*ones(1,d);
    
    % M:
    k_t = 1;
    k_s = 1;
    param.k_t = k_t;
    param.k_s = k_s;
    param.alpha = alpha;
    param.M_t{i} = k_t * diag(ones(1,d));
    param.M_s{i} = k_s * diag(ones(1,d));
    param.M_ts{i} = param.alpha * sqrt(k_t * k_s) * eye(d);
    param.M{i} = [param.M_t{i} param.M_ts{i}; param.M_ts{i}' param.M_s{i}];
    %param.Sigma{i} = param.M{i}^-1;
    param.M_t_inv{i} = param.M_t{i}^-1;
    
    % C & F:
    param.C{i} = param.M_s{i} - param.M_ts{i}' * param.M_t_inv{i} * param.M_ts{i};
    param.C_inv{i} = param.C{i}^-1;
    param.F{i} = param.C{i}^-1 * param.M_ts{i}' * param.M_t_inv{i};
    param.F_inv{i} = param.F{i}^-1;

end
end