function [theta_mu_t, theta_Lambda_t] = sample_target_hmc_stan(fit_TL_target, Sz_sample, param, X_train, n_t, nchains, seed)
L = param.L;
d = param.d;
theta_mu_t = cell(Sz_sample, L);
theta_Lambda_t = cell(Sz_sample, L);
param_samples = cell(1, L);
sample_Lambda_t = cell(1, L);
sample_mu_t = cell(1, L);

for l = 1:L
    TL_target_data = struct('n_t', n_t, 'd', d, 'm_t', param.m_t{l}, 'kappa_t', param.kappa_t{l}, 'M_t', param.M{l}(1:d,1:d), 'nu', param.nu{l}, 'x', X_train.t{l});
    fit = stan('fit', fit_TL_target, 'data', TL_target_data, 'chains', nchains, 'iter', 2*Sz_sample/nchains, 'thin', 1, 'seed', seed);
    fit.block();
    
    param_samples{l} = fit.extract('permuted',true,'par', {'mu_t' 'Lambda_t'});
    sample_mu_t{l} = param_samples{l}.mu_t;
    sample_Lambda_t{l} = param_samples{l}.Lambda_t;
end

for t = 1:Sz_sample
    for l = 1:L
        theta_mu_t{t,l} = sample_mu_t{l}(t,:);
        theta_Lambda_t{t,l} = squeeze(sample_Lambda_t{l}(t,:,:));
    end
end
end