function [X, S, Label] = generate_data(mu_t,mu_s,Lambda_t,Lambda_s,nc ,n_t,n_s,n_test, seed)

X.test = cell(1, nc);
X.t = cell(1, nc);
X.s = cell(1, nc);
X.t_mean = cell(1, nc);
X.s_mean = cell(1, nc);
S.t = cell(1, nc);
S.s = cell(1, nc);
X.test_all = [];
Label.test_all = [];

for i = 1:nc
    
    % Test (for target)
    rng(seed);
    X.test{i} = mvnrnd(mu_t{i},Lambda_t{i}^(-1),n_test);
    X.test_all = [X.test_all; X.test{i}];
    Label.test{i} = i * ones(1,n_test);
    Label.test_all = [Label.test_all Label.test{i}];
    
    
    % Train (for both target and source)
    if n_t > 0
        rng(seed);
        X.t{i} = mvnrnd(mu_t{i},Lambda_t{i}^(-1),n_t);
    else
        X.t{i} = 0;
    end
    Label.t{i} = i * ones(1,n_t);
    
    if n_s > 0
        rng(seed);
        X.s{i} = mvnrnd(mu_s{i},Lambda_s{i}^(-1),n_s);
    else
        X.s{i} = 0;
    end
    Label.s{i} = i * ones(1,n_s);
    
    
    % Sample mean and covariance
    if n_t ~= 1
        X.t_mean{i} = mean(X.t{i});
    else
        X.t_mean{i} = X.t{i};
    end
    
    if n_s ~= 1
        X.s_mean{i} = mean(X.s{i});
    else
        X.s_mean{i} = X.s{i};
    end
    
    S.t{i} = (X.t{i} - repmat(X.t_mean{i},n_t,1))' * (X.t{i} - repmat(X.t_mean{i},n_t,1));
    S.s{i} = (X.s{i} - repmat(X.s_mean{i},n_s,1))' * (X.s{i} - repmat(X.s_mean{i},n_s,1));
end

