function Q = importance_density(param, X, S, n_t)
%This function returns a function handle for the importance density
%Importance density: predictive posterior of the target parameters [P(mu_t, Lambda_t | D_t)]

L = param.L;

kappa_t_n = cell(1,L);
m_t_n = cell(1,L);
M_t_n_inv = cell(1,L);
T_t_inv = cell(1,L);

for i = 1:L
    kappa_t_n{i} = param.kappa_t{i} + n_t;
    m_t_n{i} = (param.kappa_t{i} * param.m_t{i} + n_t * X.t_mean{i})/(param.kappa_t{i} + n_t);
    m_t_n{i} = reshape(m_t_n{i},[],1);
    M_t_n_inv{i} = param.M_t_inv{i} + S.t{i} + (param.kappa_t{i} * n_t/(param.kappa_t{i} + n_t)) * (param.m_t{i} - X.t_mean{i})' * (param.m_t{i} - X.t_mean{i});
    T_t_inv{i} = M_t_n_inv{i} + param.F{i}' * param.C{i} * param.F{i};
end

for i = 1:L
    Q{i} = @(mu_t,Lambda_t) exp(...
                                - (param.d/2)*(log(2*pi)-log(kappa_t_n{i})) -  (param.d*(param.nu{i}+n_t)/2)*log(2) - gamma_multi_ln(param.d, (param.nu{i}+n_t)/2)...
                                - ((param.nu{i}+n_t)/2)*log(det(M_t_n_inv{i}^(-1))) + (1/2)*log(det(Lambda_t)) - (kappa_t_n{i}/2) * (mu_t - m_t_n{i})' * Lambda_t * (mu_t - m_t_n{i})...
                                + ((param.nu{i}+n_t-param.d-1)/2)*log(det(Lambda_t)) + trace((-1/2)*M_t_n_inv{i}*Lambda_t)...
                                );
end
end

