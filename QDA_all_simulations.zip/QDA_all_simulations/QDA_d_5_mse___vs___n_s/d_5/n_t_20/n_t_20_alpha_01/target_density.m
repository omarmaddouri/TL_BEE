function P = target_density(param, hg_mode, X, S, n_t, n_s)
%This function returns a function handle for the target density
%Target density: predictive posterior of the target parameters [P(mu_t, Lambda_t | D_t,D_s)]

L = param.L;

kappa_t_n = cell(1,L);
m_t_n = cell(1,L);
M_t_n_inv = cell(1,L);
T_t_inv = cell(1,L);
T_s_inv = cell(1,L);
Eig_21 = cell(1,L);
Eig_11 = cell(1,L);

for i = 1:L
    kappa_t_n{i} = param.kappa_t{i} + n_t;
    m_t_n{i} = (param.kappa_t{i} * param.m_t{i} + n_t * X.t_mean{i})/(param.kappa_t{i} + n_t);
    m_t_n{i} = reshape(m_t_n{i},[],1);
    M_t_n_inv{i} = param.M_t_inv{i} + S.t{i} + (param.kappa_t{i} * n_t/(param.kappa_t{i} + n_t)) * (param.m_t{i} - X.t_mean{i})' * (param.m_t{i} - X.t_mean{i});
    T_t_inv{i} = M_t_n_inv{i} + param.F{i}' * param.C{i} * param.F{i};
    T_s_inv{i} = param.C_inv{i} + S.s{i} + (param.kappa_s{i} * n_s/(param.kappa_s{i} + n_s)) * (param.m_s{i} - X.s_mean{i})' * (param.m_s{i} - X.s_mean{i});
    %F21 computation is function of eigenvalues
    Omega_inv = param.F_inv{i}' * T_t_inv{i} * param.F_inv{i} * T_s_inv{i};
    Eig_21{i} = real(1./eig(Omega_inv)');
    %F11 computation is function of eigenvalues
    Omega_11_inv = @(Lambda_t) 2 * T_s_inv{i} * param.F_inv{i}' * Lambda_t^(-1) * param.F_inv{i};
    Eig_11{i} = @(Lambda_t) real(1./eig(Omega_11_inv(Lambda_t))');
end

log_HG_21 = zeros(1,L);
switch hg_mode
    case 'Laplace_approx'
        for i = 1:L
            log_HG_21(i) = approx_F21((param.nu{i} + n_s)/2, (param.nu{i} + n_t)/2, param.nu{i}/2, Eig_21{i});
        end
    case 'truncated_sum_MIT'
        for i = 1:L
            log_HG_21(i) = F21_MIT((param.nu{i} + n_s)/2, (param.nu{i} + n_t)/2, param.nu{i}/2, Eig_21{i});
        end
    case 'truncated_sum_Chan'
        for i = 1:L
            log_HG_21(i) = F21_Chan((param.nu{i} + n_s)/2, (param.nu{i} + n_t)/2, param.nu{i}/2, Eig_21{i});
        end
end


log_HG_11 = cell(1,L);
switch hg_mode
    case 'Laplace_approx'
        for i = 1:L
            log_HG_11{i} = @(Lambda_t) approx_F11((param.nu{i} + n_s)/2, param.nu{i}/2, Eig_11{i}(Lambda_t));
        end
    case 'truncated_sum_MIT'
        for i = 1:L
            log_HG_11{i} = @(Lambda_t) F11_MIT((param.nu{i} + n_s)/2, param.nu{i}/2, Eig_11{i}(Lambda_t));
        end
    case 'truncated_sum_Chan'
        for i = 1:L
            log_HG_11{i} = @(Lambda_t) F11_Chan((param.nu{i} + n_s)/2, param.nu{i}/2, Eig_11{i}(Lambda_t));
        end
end

log_A = zeros(1,L);
for i = 1:L
    log_A(i) = -(param.d/2) * log(2*pi/kappa_t_n{i}) - param.d * ((param.nu{i} + n_t)/2) * log(2) - gamma_multi_ln(param.d,(param.nu{i} + n_t)/2)...
    - ((param.nu{i} + n_t)/2) * log(det(T_t_inv{i}^(-1))) - log_HG_21(i);
end

P = cell(1,L);
for i = 1:L
    P{i} = @(mu_t,Lambda_t) exp(...
                                log_A(i) + (1/2)*log(det(Lambda_t)) - (kappa_t_n{i}/2) * (mu_t - m_t_n{i})' * Lambda_t * (mu_t - m_t_n{i})...
                                + ((param.nu{i} + n_t - param.d - 1)/2) * log(det(Lambda_t)) + trace((-1/2)*T_t_inv{i} * Lambda_t) + log_HG_11{i}(Lambda_t)...
                                );
end

end