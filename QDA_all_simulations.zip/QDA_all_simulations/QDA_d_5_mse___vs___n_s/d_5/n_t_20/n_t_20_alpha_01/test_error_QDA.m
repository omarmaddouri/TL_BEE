function error = test_error_QDA(QDA, param, mu_t, Lambda_t, N_test, seed)
L = param.L;

[X, ~, Label] = generate_data(mu_t, 0, Lambda_t, 0, L, 0, 0, N_test, seed);

    X_test = X.test_all;
    Label_test = Label.test_all;
    n_test = length(Label_test);

    Label_pred = zeros(1,n_test);
    for i = 1:n_test
        x = X_test(i,:);    
        x = reshape(x,[],1);
        Label_pred(i) = x' * QDA.A * x + x' * QDA.a + QDA.b;
    end

    Label_pred(Label_pred>0) = 2;
    Label_pred(Label_pred<=0) = 1;
    accuracy = sum(Label_pred == Label_test)/n_test;
    error = 1 - accuracy;
end