function error_class = true_error_LDA(param, classifier, Lambda, mu)
L = param.L;
error_class = ones(1, L);
for i = 1:L
    mu{i} = reshape(mu{i},[],1);
    error_class(i) = normcdf((-1)^(i-1)*(classifier.a' * mu{i} + classifier.b)/sqrt(classifier.a' * Lambda{i}^(-1) * classifier.a));
end
end