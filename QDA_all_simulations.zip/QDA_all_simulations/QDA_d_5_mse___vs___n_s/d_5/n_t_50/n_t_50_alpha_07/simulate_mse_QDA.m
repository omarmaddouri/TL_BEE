%% Clear environment and add required paths
clear;clc;
warning('off','all')
format longE; %Increase float precision
addpath('./HG_MIT');
addpath('./HG_Chan');
addpath('/scratch/user/omar.maddouri/STAN/MatlabStan-2.15.1.0')
addpath('/scratch/user/omar.maddouri/STAN/MatlabProcessManager')
addpath('D:/Installations/STAN/MatlabStan-2.15.1.0')
addpath('D:/Installations/STAN/MatlabProcessManager')

%% Define STAN model code
% Stan code for posterior of target parameters
% Wishart distribution re-parameterized using Bartlett decomposition
JPo_t_code = {
'data {'
'    int<lower=0> n_t;'
'    int<lower=2> d;'
'    vector[d] m_t;'
'    int<lower=0> kappa_t;'
'    matrix[d,d] M_t;'
'    int<lower=d> nu;'
'    matrix[n_t,d] x;'
'}'
'transformed data{'
'    matrix[d,d] L_M_t;'
'    L_M_t = cholesky_decompose(M_t);'
'}'
'parameters {'
'    vector[d] mu_t;'
'    vector<lower=0>[d] c_Lambda_t;'
'    vector[d*(d-1)/2] n_Lambda_t;'
'}'
'transformed parameters{'
'    matrix[d,d] A_Lambda_t;'
'    matrix[d,d] Lambda_t;'
'    for (i in 1:d){'
'        for (j in 1:d){'
'            if(i==j)'
'               A_Lambda_t[i,j] = sqrt(c_Lambda_t[i]);'
'            else if(i>j)'
'               A_Lambda_t[i,j] = n_Lambda_t[(j+(i-1)*(i-2)/2)];'
'            else'
'               A_Lambda_t[i,j] = 0.0;'
'        }'
'    }'
'    Lambda_t = L_M_t * A_Lambda_t * A_Lambda_t'' * L_M_t'';'
'}'
'model {'
'     for (i in 1:d){'
'         c_Lambda_t[i] ~ chi_square(nu-i+1);'
'     }'
'    for (i in 1:d*(d-1)/2){'
'         n_Lambda_t[i] ~ normal(0, 1);'
'     }'
'   mu_t ~ multi_normal(m_t, inverse(kappa_t*Lambda_t));'
'   for (i in 1:n_t){'
'       x[i,:] ~ multi_normal(mu_t, inverse(Lambda_t));'
'   }'
'}'
 };
% Stan code for joint posterior of target and source parameters
% Wishart distribution re-parameterized using Bartlett decomposition
JPo_ts_code = {
'data {'
'    int<lower=0> n_t;'
'    int<lower=0> n_s;'
'    int<lower=2> d;'
'    vector[d] m_t;'
'    vector[d] m_s;'
'    int<lower=0> kappa_t;'
'    int<lower=0> kappa_s;'
'    matrix[2*d,2*d] M;'
'    int<lower=d> nu;'
'    matrix[n_t+n_s,d] x;'
'}'
'transformed data{'
'    matrix[2*d,2*d] L_M;'
'    L_M = cholesky_decompose(M);'
'}'
'parameters {'
'    vector[d] mu_t;'
'    vector[d] mu_s;'
'    vector<lower=0>[2*d] c_Lambda;'
'    vector[d*(2*d-1)] n_Lambda;'
'}'
'transformed parameters{'
'    matrix[2*d,2*d] A_Lambda;'
'    matrix[2*d,2*d] Lambda;'
'    matrix[d,d] Lambda_t;'
'    matrix[d,d] Lambda_s;'
'    for (i in 1:2*d){'
'        for (j in 1:2*d){'
'            if(i==j)'
'               A_Lambda[i,j] = sqrt(c_Lambda[i]);'
'            else if(i>j)'
'               A_Lambda[i,j] = n_Lambda[(j+(i-1)*(i-2)/2)];'
'            else'
'               A_Lambda[i,j] = 0.0;'
'        }'
'    }'
'    Lambda = L_M * A_Lambda * A_Lambda'' * L_M'';'
'    Lambda_t = Lambda[1:d,1:d];'
'    Lambda_s = Lambda[(d+1):(2*d),(d+1):(2*d)];'
'}'
'model {'
'     for (i in 1:2*d){'
'         c_Lambda[i] ~ chi_square(nu-i+1);'
'     }'
'    for (i in 1:d*(2*d-1)){'
'         n_Lambda[i] ~ normal(0, 1);'
'     }'
'   mu_t ~ multi_normal(m_t, inverse(kappa_t*Lambda_t));'
'   mu_s ~ multi_normal(m_s, inverse(kappa_s*Lambda_s));'
'   for (i in 1:n_t){'
'       x[i,:] ~ multi_normal(mu_t, inverse(Lambda_t));'
'   }'
'   for (i in n_t+1:n_t+n_s){'
'       x[i,:] ~ multi_normal(mu_s, inverse(Lambda_s));'
'   }'
'}'
 };

%% Define constants
d = 5;  % Number of features
L = 2;   % Number of classes
N_t = [50];%[10, 20, 30, 40, 50]; % Target data per class
N_s = [10, 50, 100, 150, 200, 250, 300, 350, 400, 450, 500]; % Source data per class
        
N_test = 10^(3); % Number of test target data per class
Sz_sample = 10^(3); % Size of MC sample (rule of thumb -> 10 times more than the quantity being estimated)
N_p = 10^(0); % Number of repeats of the simulations for different parameters (only one repition is sufficient to get the correct behaviour)
N_d = 10^(3); % Number of repeats with different datasets to estimate the MSE

%Alpha = [0.95, 0.9, 0.7, 0.5, 0.3, 0.1];% Different relatedness coefficients
Alpha = [0.7];% Different relatedness coefficients

Sz_target = length(N_t); % size of array containing train target data numbers
Sz_source = length(N_s); % size of array containing train source data numbers
Sz_alpha = length(Alpha); % size of array containing train source data numbers

complexity_Bayes_error = 0.2;
eps_error = 10^(-6);
nu = 25;
mean_shift = 1;

sampling_mode = 'stan_target_posterior_hmc';%'stan_target_posterior_hmc','stan_joint_posterior_hmc'
hg_mode = 'Laplace_approx'; % 'Laplace_approx', 'truncated_sum_MIT', 'truncated_sum_Chan'
nchains = 4;% Number of sampling chains for STAN
seed = 123; %Random seed
seeds = zeros(1, N_d);

%% Define Global variables
Avg_MSE_QDA = zeros(Sz_alpha, Sz_target, Sz_source); % Average MSE after N_p trials
Avg_Bayes_error = zeros(1, Sz_alpha); % Average Bayes error across all relatedness coefficients
Bayes_error = zeros(1, N_p);
MSE_QDA = zeros(N_p, Sz_target, Sz_source);

param = setup_parameters(d, L, mean_shift, nu, Alpha(1));
%% Note: the STAN model needs to be recompiled for different OS systems (i.e.: Windows, Linux, Mac, ...)
if (~exist('target_posterior_QDA.stan', 'file'))
    TL_target_data = struct('n_t', N_t(1), 'd', d, 'm_t', param.m_t{1}, 'kappa_t', param.kappa_t{1}, 'M_t', param.M{1}(1:d,1:d), 'nu', param.nu{1}, 'x', randn(N_t(1),d));
    fit_TL_target_initial = stan('model_code', JPo_t_code, 'data', TL_target_data,'model_name', 'target_posterior_QDA', 'chains', 1, 'iter', 100, 'file_overwrite', true);
    fit_TL_target_initial.block();
else
    fit_TL_target_initial = stan('file', 'target_posterior_QDA.stan');
end
if (~exist('joint_posterior_QDA.stan', 'file'))
    TL_joint_data = struct('n_t', N_t(1), 'n_s', N_s(1), 'd', d, 'm_t', param.m_t{1}, 'm_s', param.m_s{1}, 'kappa_t', param.kappa_t{1}, 'kappa_s', param.kappa_s{1}, 'M', param.M{1}, 'nu', param.nu{1}, 'x', randn(N_t(1)+N_s(1),d));
    fit_TL_joint_initial = stan('model_code', JPo_ts_code, 'data', TL_joint_data,'model_name', 'joint_posterior_QDA', 'chains', 1, 'iter', 100, 'file_overwrite', true);
    fit_TL_joint_initial.block();
else
    fit_TL_joint_initial = stan('file', 'joint_posterior_QDA.stan');
end

%% Simulations
rng(seed);
for n_d = 1:N_d
	seeds(n_d) = randi([100,999]);
end
%% LOOP over relatedness coefficients
for alpha_idx = 1:Sz_alpha
    alpha = Alpha(alpha_idx);
    fprintf('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%\n');
    fprintf('---> alpha = %.2f ### (%.2d/%.2d)\n', alpha, alpha_idx, Sz_alpha);
    %% LOOP for different parameters realisations
    for n_p = 1:N_p
        SE_QDA = zeros(N_d, Sz_target, Sz_source);
        verbosity = 0; %Used to display Bayer error for each alpha
        rng(seed);
        
        fprintf('---------> N_p = (%.2d/%.2d)\n', n_p, N_p);
        %% Sample New Parameters
        param = setup_parameters(d, L, mean_shift, nu, alpha);
        mu_t = cell(1, L);
        mu_s = cell(1, L);
        Lambda = cell(1, L);
        Lambda_t = cell(1, L);
        Lambda_s = cell(1, L);
        Sigma_t = cell(1, L);
        for l = 1:L
            Lambda{l} = wishrnd(param.M{l},param.nu{l});
            Lambda_t{l} = Lambda{l}(1:d,1:d);
            Sigma_t{l} = Lambda_t{l}^(-1);
            Lambda_s{l} = Lambda{l}((d+1):2*d,(d+1):2*d);
        end
        
        Bayes_error(n_p)=0;
        while true
            for l = 1:L
                mu_t{l} = mvnrnd(param.m_t{l},(param.kappa_t{l} * Lambda_t{l})^(-1));
                mu_s{l} = mvnrnd(param.m_s{l},(param.kappa_s{l} * Lambda_s{l})^(-1));
            end
            %% Determine the optimal QDA classifier (Bayes classifier)
            QDA_Bayes = train_QDA(mu_t, Lambda_t, L);

            %% Compute Bayes Error
            Bayes_error(n_p) = test_error_QDA(QDA_Bayes, param, mu_t, Lambda_t, N_test, seed);
            
            if abs(Bayes_error(n_p) - complexity_Bayes_error) < eps_error
                break
            end
            if Bayes_error(n_p) > complexity_Bayes_error
                mean_shift = (mean_shift * 2) * (1 + rand);
            elseif Bayes_error(n_p) < complexity_Bayes_error
                mean_shift = (mean_shift / 2) * rand;
            end
            
            if mean_shift==0 && Bayes_error(n_p) < complexity_Bayes_error
                for l = 1:L
                    Lambda{l} = wishrnd(param.M{l},param.nu{l});
                    Lambda_t{l} = Lambda{l}(1:d,1:d);
                    Sigma_t{l} = Lambda_t{l}^(-1);
                    Lambda_s{l} = Lambda{l}((d+1):2*d,(d+1):2*d);
                end
				mean_shift = rand;
			elseif mean_shift==0 && Bayes_error(n_p) > complexity_Bayes_error
                mean_shift = rand;
            end
            param = setup_parameters(d, L, mean_shift, nu, alpha);
        end
        
        if(alpha_idx > verbosity)
            fprintf('---------> Bayes error = %.4f\n', Bayes_error(n_p));
            verbosity = alpha_idx;
        end
        
        %% Loop for different datasets realisations
        % To parallelize different loops (i.e.: N_s), the STAN model
        % instances need to be updated accordingly.
        parfor n_d = 1:N_d
            BEE_QDA = zeros(1, Sz_source);                
            BEE_QDA_class = zeros(L, Sz_source);
            
            if ~exist([tempdir 'worker_' num2str(n_d)], 'dir')
                mkdir([tempdir 'worker_' num2str(n_d)]);
            end            
            
            TL_target_data(n_d) = struct('n_t', N_t(1), 'd', d, 'm_t', param.m_t{1}, 'kappa_t', param.kappa_t{1}, 'M_t', param.M{1}(1:d,1:d), 'nu', param.nu{1}, 'x', randn(N_t(1),d));
            fit_TL_target(n_d) = stan('fit', fit_TL_target_initial, 'data', TL_target_data(n_d), 'chains', 1, 'iter', 100, 'working_dir',[tempdir 'worker_' num2str(n_d)], 'seed', seeds(n_d));
            fit_TL_target(n_d).block();
            
            TL_joint_data(n_d) = struct('n_t', N_t(1), 'n_s', N_s(1), 'd', d, 'm_t', param.m_t{1}, 'm_s', param.m_s{1}, 'kappa_t', param.kappa_t{1}, 'kappa_s', param.kappa_s{1}, 'M', param.M{1}, 'nu', param.nu{1}, 'x', randn(N_t(1)+N_s(1),d));
            fit_TL_joint(n_d) = stan('fit', fit_TL_joint_initial, 'data', TL_joint_data(n_d), 'chains', 1, 'iter', 100, 'working_dir',[tempdir 'worker_' num2str(n_d)]);
            fit_TL_joint(n_d).block();
                    
            fprintf('---------------> N_d = (%.2d/%.2d) ---> (alpha = %.2f)\n', n_d, N_d, alpha);
            % We generate the largest dataset first, and then we extract
            % sub-datasets as needed to facilitate the reproducibility
            % across the experiments.
            [X_full, ~, ~] = generate_data(mu_t, mu_s, Lambda_t, Lambda_s, L, N_t(end), N_s(end), N_test, seeds(n_d));
            for n_t_idx = 1:Sz_target
                n_t = N_t(n_t_idx);
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                [X_train, S_train] = get_partial_data(X_full, L, n_t, N_s(end));
                %% Control variate classifier (LDA classifier)
                LDA_variate = train_LDA(X_train.t_mean, S_train.t, L);
                H = control_variate(LDA_variate);
                switch sampling_mode
                    case 'stan_target_posterior_hmc'
                        [theta_mu_t, theta_Lambda_t] = sample_target_hmc_stan(fit_TL_target(n_d), Sz_sample, param, X_train, n_t, nchains, seeds(n_d));
                end
                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                 fprintf('---------------------> N_t = %.2d ### (%.2d/%.2d) ---> (alpha = %.2f)\n', n_t, n_t_idx, Sz_target, alpha);
                for n_s_idx = 1:Sz_source
                    n_s = N_s(n_s_idx);                                        
                    
%                     if ~exist([tempdir 'worker_' num2str(n_s_idx)], 'dir')
%                         mkdir([tempdir 'worker_' num2str(n_s_idx)]);
%                     end
%                     TL_joint_data(n_s_idx) = struct('n_t', n_t, 'n_s', n_s, 'd', d, 'm_t', param.m_t{1}, 'm_s', param.m_s{1}, 'kappa_t', param.kappa_t{1}, 'kappa_s', param.kappa_s{1}, 'M', param.M{1}, 'nu', param.nu{1}, 'x', randn(n_t+n_s,d));
%                     fit_TL_joint(n_s_idx) = stan('fit', fit_TL_joint_initial, 'data', TL_joint_data(n_s_idx), 'chains', 1, 'iter', 100, 'working_dir',[tempdir 'worker_' num2str(n_s_idx)], 'seed', seeds(n_d));
%                     fit_TL_joint(n_s_idx).block();
            
                    Mixed_BEE = zeros(1, Sz_sample);                    
                    Mixed_BEE_class = zeros(L, Sz_sample);
                    fprintf('---------------------------> N_s = %.2d ### (%.2d/%.2d) ---> (alpha = %.2f)\n', n_s, n_s_idx, Sz_source, alpha);
%                     [X_train, S_train, ~] = generate_data(mu_t, mu_s, Lambda_t, Lambda_s, L, n_t, n_s, N_test, seeds(n_d));
                    [X_train, S_train] = get_partial_data(X_full, L, n_t, n_s);
                    switch sampling_mode
                        case 'stan_target_posterior_hmc'
                            [kappa_t_n, m_t_n, T_t, T_t_inv, T_s_inv, M_t_n] = get_params(param, X_train, S_train, n_t, n_s);
                            nu_tmp = cell(1,L);
                            for i = 1:L
                                nu_tmp{i} = param.nu{i}+n_t;
                            end
                            P = target_density(param, hg_mode, X_train, S_train, n_t, n_s);
                            Q = importance_density(param, X_train, S_train, n_t);
                            EH = expected_control_variate(param, LDA_variate, M_t_n, nu_tmp, m_t_n, kappa_t_n);
                            f = zeros(Sz_sample,L);
                            IW = importance_weights(param, theta_mu_t, theta_Lambda_t, P, Q);
                            M = zeros(1, L);
                            for i = 1:L
                                M(i) = max(log(IW(:,i)));
                            end
                            IW = exp(log(IW) - M);
                            IW = exp( log(IW) - log(sum(IW,1)) );
                            
                            for t = 1:Sz_sample
                                try
                                    f(t,:) = class_test_error_QDA(QDA_Bayes, param, {theta_mu_t{t,:}}, {theta_Lambda_t{t,:}}, N_test, seeds(n_d));
                                catch ME
                                    for i=1:L
                                        f(t,i) = -1;
                                    end
                                end
                            end
                            [CW, beta] = control_variate_weights(param, theta_mu_t, theta_Lambda_t, H, EH, IW, f);
                            for t = 1:Sz_sample
                                for i=1:L
                                    if(f(t,i) == -1)
                                        Mixed_BEE_class(i, t) =  -1;
                                    else
                                        Mixed_BEE_class(i, t) =  IW(t,i) .* f(t,i);
                                    end
                                end
                            end
                            %In very rare cases, the sampled precision
                            %matrix is singular. We remove such glitches by
                            %considering the mean error across all other
                            %parameters.
                            for i=1:L
                                tmp_Mixed_BEE_class = Mixed_BEE_class(i,:);
                                tmp_Mixed_BEE_class(tmp_Mixed_BEE_class==-1) = mean(tmp_Mixed_BEE_class(tmp_Mixed_BEE_class~=-1),2);
                                Mixed_BEE_class(i,:) = tmp_Mixed_BEE_class;
                            end
                            %% Importance sampling estimate:
                            BEE_QDA_class(:, n_s_idx) = (1./sum(IW, 1)) .* sum(Mixed_BEE_class, 2)' - (1/Sz_sample) * beta .* sum(CW, 1) + beta.*cell2mat(EH);
                            BEE_QDA(n_s_idx) = mean(BEE_QDA_class(:, n_s_idx));
                        
                        % For direct evaluation, we sample from the joint
                        % model and retain only the target parameters.
                        case 'stan_joint_posterior_hmc'
                            [theta_mu_t, theta_Lambda_t] = sample_joint_hmc_stan(fit_TL_joint(n_d), Sz_sample, param, X_train, n_t, n_s, nchains, seeds(n_d));
                            for t = 1:Sz_sample
                                try
                                    Mixed_BEE(t) = test_error_QDA(QDA_Bayes, param, {theta_mu_t{t,:}}, {theta_Lambda_t{t,:}}, N_test, seeds(n_d));
                                catch ME
                                    Mixed_BEE(t) = -1;
                                end
                            end
                            Mixed_BEE(Mixed_BEE==-1) = mean(Mixed_BEE(Mixed_BEE~=-1));
                            BEE_QDA(n_s_idx) = (1/Sz_sample) * sum( Mixed_BEE);
                    end
                end
                % Compute the squared error of the BEE
                SE_QDA(n_d, n_t_idx, :) = (BEE_QDA - Bayes_error(n_p)).^2;
            end
        end
        % Estimate MSE for a given n_t
        MSE_QDA(n_p,:,:) = mean(SE_QDA,1);
    end
    Avg_MSE_QDA(alpha_idx,:,:) = mean(MSE_QDA, 1);
    Avg_Bayes_error(alpha_idx) = mean(Bayes_error);
    
    %% Save results
    for n_t_idx =1:Sz_target
        save_name = sprintf('QDA_MSE_n_t_%1d_alpha_%g.mat', N_t(n_t_idx), Alpha(:));
        save(save_name, 'Sz_target', 'Sz_source', 'Sz_alpha',...
            'Avg_MSE_QDA', 'N_t', 'N_s', 'Alpha', 'Avg_Bayes_error');
    end
end