module load Matlab/R2020a
alias matlabsubmit_customized='$SCRATCH/matlabsubmit_customized/matlabsubmit'
cd d_2/n_s_50/n_s_50_cl_resub
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_s_50_cl_cv
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_s_50_cl_loo
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_s_50_cl_bootstrap
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_s_50_cl_bee
matlabsubmit_customized -t 10:00 -w 28 simulate_mse_QDA.m

cd ../../n_s_200/n_s_200_cl_resub
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_s_200_cl_cv
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_s_200_cl_loo
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_s_200_cl_bootstrap
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m
cd ../n_s_200_cl_bee
matlabsubmit_customized -t 10:00 -w 20 simulate_mse_QDA.m