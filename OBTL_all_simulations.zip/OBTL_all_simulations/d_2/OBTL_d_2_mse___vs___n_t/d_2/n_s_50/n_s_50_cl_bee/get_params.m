function [kappa_t_n, m_t_n, T_t, T_t_inv, T_s_inv] = get_params(param, X, S, n_t, n_s)
L = param.L;

kappa_t_n = cell(1,L);
m_t_n = cell(1,L);
M_t_n_inv = cell(1,L);
T_t_inv = cell(1,L);
T_s_inv = cell(1,L);
T_t = cell(1,L);

for i = 1:L
    kappa_t_n{i} = param.kappa_t{i} + n_t;
    m_t_n{i} = (param.kappa_t{i} * param.m_t{i} + n_t * X.t_mean{i})/(param.kappa_t{i} + n_t);
    m_t_n{i} = reshape(m_t_n{i},[],1);
    M_t_n_inv{i} = param.M_t_inv{i} + S.t{i} + (param.kappa_t{i} * n_t/(param.kappa_t{i} + n_t)) * (param.m_t{i} - X.t_mean{i})' * (param.m_t{i} - X.t_mean{i});
    T_t_inv{i} = M_t_n_inv{i} + param.F{i}' * param.C{i} * param.F{i};
    T_s_inv{i} = param.C_inv{i} + S.s{i} + (param.kappa_s{i} * n_s/(param.kappa_s{i} + n_s)) * (param.m_s{i} - X.s_mean{i})' * (param.m_s{i} - X.s_mean{i});
    T_t{i} = T_t_inv{i}^(-1);
end