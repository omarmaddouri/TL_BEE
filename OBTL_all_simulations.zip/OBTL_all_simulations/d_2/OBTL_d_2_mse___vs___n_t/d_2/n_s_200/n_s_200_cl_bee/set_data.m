function [X, S, Label, n_t, n_s] = set_data(X_input, Label_input, n_t_input, n_s_input, nc)

    X.test = cell(1, nc);
    X.t = cell(1, nc);
    X.s = cell(1, nc);
    X.t_mean = cell(1, nc);
    X.s_mean = cell(1, nc);
    S.t = cell(1, nc);
    S.s = cell(1, nc);
    X.test_all = [];
    Label.test_all = [];

    n_t = n_t_input;
    n_s = n_s_input;

    for i = 1:nc
        
        % Test (for target)
        X.test{i} = X_input.test{i};
        X.test_all = [X.test_all; X.test{i}];
        Label.test{i} = Label_input.test{i};
        Label.test_all = [Label.test_all Label.test{i}];
        
        
        % Train (for both target and source)
        if n_t_input > 0
            X.t{i} = X_input.t{i};
        else
            X.t{i} = 0;
        end
        Label.t{i} = Label_input.t{i};
        
        if n_s_input > 0
            X.s{i} = X_input.s{i};
        else
            X.s{i} = 0;
        end
        Label.s{i} = Label_input.s{i};
        
        
        % Sample mean and covariance
        if n_t_input ~= 1
            X.t_mean{i} = mean(X.t{i});
        else
            X.t_mean{i} = X.t{i};
        end
        
        if n_s_input ~= 1
            X.s_mean{i} = mean(X.s{i});
        else
            X.s_mean{i} = X.s{i};
        end
        
        S.t{i} = (X.t{i} - repmat(X.t_mean{i},n_t_input,1))' * (X.t{i} - repmat(X.t_mean{i},n_t_input,1));
        S.s{i} = (X.s{i} - repmat(X.s_mean{i},n_s_input,1))' * (X.s{i} - repmat(X.s_mean{i},n_s_input,1));
    end
end