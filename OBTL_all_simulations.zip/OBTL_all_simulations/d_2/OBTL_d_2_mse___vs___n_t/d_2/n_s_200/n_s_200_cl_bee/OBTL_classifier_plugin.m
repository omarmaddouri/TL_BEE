function [error, accuracy] = OBTL_classifier_plugin(X, S, Label, paramchoose, n_t, n_s, N_test, seed)
    L = paramchoose.L;
    
    Lambda_plugin.t = cell(1, L);
    for i = 1:L
    Lambda_plugin.t{i} = S.t{i}^(-1);
    end
    
    [X_plugin, ~, Label_plugin] = generate_data(X.t_mean, 0, Lambda_plugin.t, 0, L, 0, 0, N_test, seed);
    
    kappa_t_n = cell(1,L);
    m_t_n = cell(1,L);
    M_t_n_inv = cell(1,L);
    T_t_inv = cell(1,L);
    T_s_inv = cell(1,L);
    Eig = cell(1,L);
    approx_hg = 1;

    for i = 1:L
        kappa_t_n{i} = paramchoose.kappa_t{i} + n_t;
        m_t_n{i} = (paramchoose.kappa_t{i} * paramchoose.m_t{i} + n_t * X.t_mean{i})/(paramchoose.kappa_t{i} + n_t);
        M_t_n_inv{i} = paramchoose.M_t_inv{i} + S.t{i} + (paramchoose.kappa_t{i} * n_t/(paramchoose.kappa_t{i} + n_t)) * (paramchoose.m_t{i} - X.t_mean{i})' * (paramchoose.m_t{i} - X.t_mean{i});
        T_t_inv{i} = M_t_n_inv{i} + paramchoose.F{i}' * paramchoose.C{i} * paramchoose.F{i};
        T_s_inv{i} = paramchoose.C_inv{i} + S.s{i} + (paramchoose.kappa_s{i} * n_s/(paramchoose.kappa_s{i} + n_s)) * (paramchoose.m_s{i} - X.s_mean{i})' * (paramchoose.m_s{i} - X.s_mean{i});
        Omega_inv = paramchoose.F_inv{i}' * T_t_inv{i} * paramchoose.F_inv{i} * T_s_inv{i};
        Eig{i} = real(1./eig(Omega_inv)');
    end

    X_test = X_plugin.test_all;
    label_test = Label_plugin.test_all;
    n_test = length(label_test);


    switch approx_hg
        
        case 1
            log_HG = zeros(1,L);
            for i = 1:L
                log_HG(i) = approx_F21((paramchoose.nu{i} + n_s)/2, (paramchoose.nu{i} + n_t)/2, paramchoose.nu{i}/2, Eig{i});
            end
            
            label = zeros(1,n_test);
            for j = 1:n_test
                %i
                x = X_test(j,:);
                p_X = zeros(1,L);
                for i = 1:L
                    T_X_inv = T_t_inv{i} + (kappa_t_n{i}/(kappa_t_n{i} + 1)) * (m_t_n{i} - x)' * (m_t_n{i} - x);
                    Omega_X_inv = paramchoose.F_inv{i}' * T_X_inv * paramchoose.F_inv{i} * T_s_inv{i};
                    Eig_X = real(1./eig(Omega_X_inv)');
                    log_HG_X = approx_F21((paramchoose.nu{i} + n_s)/2, (paramchoose.nu{i} + n_t + 1)/2, paramchoose.nu{i}/2, Eig_X);                
                    p_X(i) = -((paramchoose.nu{i} + n_t + 1)/2) * log(det(T_X_inv)) + ((paramchoose.nu{i} + n_t)/2) * log(det(T_t_inv{i})) + log_HG_X - log_HG(i);
                end
                
                [~, pos_max] = max(p_X);
                label(j) = pos_max;
                
            end
            
            accuracy = sum(label == label_test)/n_test;
            error = 1 - accuracy;
    end
end