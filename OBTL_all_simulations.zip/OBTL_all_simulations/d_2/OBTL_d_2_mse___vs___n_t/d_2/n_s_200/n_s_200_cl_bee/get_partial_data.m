function [Y, S, Label] = get_partial_data(X, nc, n_t, n_s)
    Y.t = cell(1, nc);
    Y.t_mean = cell(1, nc);

    Y.s = cell(1, nc);
    Y.s_mean = cell(1, nc);

    S.t = cell(1, nc);
    S.s = cell(1, nc);

    Y.test = X.test;
    Y.test_all = X.test_all;
    Label.test_all = [];

    for i = 1:nc
        
        n_test = size(Y.test{i},1);
        Label.test{i} = i * ones(1,n_test);
        Label.test_all = [Label.test_all Label.test{i}];
        
        if n_t > 1
            Y.t{i} = X.t{i}(1:n_t,:);
        else
            Y.t{i} = X.t{i};
        end
        Label.t{i} = i * ones(1,n_t);
        if n_t > 1
            Y.t_mean{i} = mean(Y.t{i});
        else
            Y.t_mean{i} = Y.t{i};
        end
        
        if n_s > 1
            Y.s{i} = X.s{i}(1:n_s,:);
        else
            Y.s{i} = X.s{i};
        end
        Label.s{i} = i * ones(1,n_s);
        if n_s > 1
            Y.s_mean{i} = mean(Y.s{i});
        else
            Y.s_mean{i} = Y.s{i};
        end
        
        S.t{i} = (Y.t{i} - repmat(Y.t_mean{i},n_t,1))' * (Y.t{i} - repmat(Y.t_mean{i},n_t,1));
        S.s{i} = (Y.s{i} - repmat(Y.s_mean{i},n_s,1))' * (Y.s{i} - repmat(Y.s_mean{i},n_s,1));
    end
end