function [theta_mu_t, theta_Lambda_t] = sample_joint_hmc_stan(fit_TL_joint, Sz_sample, param, X_train, n_t, n_s, nchains, seed)
L = param.L;
d = param.d;
theta_mu_t = cell(Sz_sample, L);
theta_Lambda_t = cell(Sz_sample, L);
param_samples = cell(1, L);
sample_Lambda_t = cell(1, L);
sample_mu_t = cell(1, L);

for l = 1:L
    if(n_t == 0)
        TL_joint_data = struct('n_t', n_t, 'n_s', n_s, 'd', d, 'm_t', param.m_t{l}, 'm_s', param.m_s{l}, 'kappa_t', param.kappa_t{l}, 'kappa_s', param.kappa_s{l}, 'M', param.M{l}, 'nu', param.nu{l}, 'x', X_train.s{l});
    else
        TL_joint_data = struct('n_t', n_t, 'n_s', n_s, 'd', d, 'm_t', param.m_t{l}, 'm_s', param.m_s{l}, 'kappa_t', param.kappa_t{l}, 'kappa_s', param.kappa_s{l}, 'M', param.M{l}, 'nu', param.nu{l}, 'x', [X_train.t{l};X_train.s{l}]);
    end
    fit = stan('fit', fit_TL_joint, 'data', TL_joint_data, 'chains', nchains, 'iter', 2*Sz_sample/nchains, 'thin', 1, 'seed', seed);
    fit.block();
    
    param_samples{l} = fit.extract('permuted',true,'par', {'mu_t' 'Lambda_t'});
    sample_mu_t{l} = param_samples{l}.mu_t;
    sample_Lambda_t{l} = param_samples{l}.Lambda_t;
end

for t = 1:Sz_sample
    for l = 1:L
        theta_mu_t{t,l} = sample_mu_t{l}(t,:);
        theta_Lambda_t{t,l} = squeeze(sample_Lambda_t{l}(t,:,:));
    end
end
end

